from recommand import Recommand


if __name__ == '__main__':
    r = Recommand()
    r.preprocessing()
    r.run_and_test_all_models()
    r.non_negative_matrix_factorization()
    r.recommand()