from Clustering import Clustering

if __name__ == '__main__':
    cl = Clustering()
    cl.q1()
    cl.q2()
    cl.q3()
    cl.q4()