Project 1 ReadMe

Completed by Zixia Weng(305029822) and Shunji Zhan(405030387)

Our code is organized in a class named TextAnalyzer, which contains all the importing libraries and relating methods for all the models we used in this project. It also contains some variables declared in the beginning for the easy use later in each method. In the utils.py, it contains some helper functions. In the main.py, we just run the functions in the TextAnalyzer along the project instructions from question a to j(i).

Type

Make

to run all the code. You will see the details of the output in the stdout.

Thank you so much!

