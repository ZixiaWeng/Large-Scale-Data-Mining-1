from TextAnalyzer import TextAnalyzer

if __name__ == '__main__':
    ta = TextAnalyzer()
    ta.run_all()
    # ta.a()
    # ta.b()
    # ta.c()
    # ta.d()
    # ta.e()
    # ta.f()
    # ta.g()
    # ta.h()
    # ta.i()
    # ta.j()